﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TopTrumpsConcept
{
    /// <summary>
    /// Interaction logic for AmazingGame.xaml
    /// </summary>
    public partial class AmazingGame : Window
    {
        TopTrumpsTestdbEntities db = new TopTrumpsTestdbEntities();
        private List<Card> _cards;
        Random rnd = new Random();

        public AmazingGame()
        {
            InitializeComponent();

            _cards = GetCardsFromDb();

            StartGame();
        }

        private void StartGame()
        {
            for (int i = 0; i < 10; i++)
            {
                var cardUI = CreateCardGame(_cards[rnd.Next(_cards.Count)]);
                CardPanel.Children.Add(cardUI);
            }
        }


        private UIElement CreateCardGame(Card card)
        {
            var border = new Border
            {
                Width = 120,
                Height = 175,
                Background = new SolidColorBrush(Color.FromRgb(30, 58, 95)),
                CornerRadius = new CornerRadius(15),
                BorderBrush = Brushes.Gold,
                BorderThickness = new Thickness(3),
                Padding = new Thickness(10)
            };

            var stack = new StackPanel();

            // Title
            stack.Children.Add(new TextBlock
            {
                Text = card.CardTitle,
                FontSize = 7,
                FontWeight = FontWeights.Bold,
                Foreground = Brushes.White,
                TextAlignment = TextAlignment.Center,
                Margin = new Thickness(0, 0, 0, 10),
                TextWrapping = TextWrapping.Wrap
            });

            // Image
            stack.Children.Add(new Image
            {
                Source = new BitmapImage(new Uri(card.CardImage, UriKind.RelativeOrAbsolute)),
                Height = 65,
                Stretch = Stretch.Fill,
                Margin = new Thickness(0, 0, 0, 10)
            });

            // Stats
            var stats = new StackPanel
            {
                Background = new SolidColorBrush(Color.FromRgb(46, 89, 132))
            };

            void AddStat(string name, object value)
            {
                var grid = new Grid();
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                grid.Children.Add(new TextBlock
                {
                    Text = name,
                    Foreground = Brushes.White,
                    FontSize = 10
                });

                var valText = new TextBlock
                {
                    Text = value.ToString(),
                    Foreground = Brushes.Gold,
                    FontSize = 10
                };
                Grid.SetColumn(valText, 1);
                grid.Children.Add(valText);

                stats.Children.Add(grid);
            }

            AddStat("Top Speed", card.Speed + " KM/h");
            AddStat("0-60", card.Acceleration + " Secs");
            AddStat("Handling", card.Handling + "/100");
            AddStat("Price", "€ " + card.Price);
            AddStat("Coolness", card.CoolRating + "/100");

            stack.Children.Add(stats);
            border.Child = stack;

            return border;
        }

        private List<Card> GetCardsFromDb()
        {
            // Using LINQ to Entities to fetch data from the database
            var cards = db.CardsTBLs.Select(c => new Card
            {
                CardID = c.CardID,
                CardTitle = c.CardTitle,
                Speed = (short)c.TopSpeed,
                Acceleration = (double)c.Acceleration,
                Price = (int)c.Price,
                Handling = (short)c.Handling,
                CoolRating = (short)c.CoolRating,
                CardImage = c.CardImage
            }).ToList();
            return cards;
        }
    }
}
